import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Markov {

    private static final int SEED = 5;
    private static Map<String, ArrayList<String>> seeds = new HashMap<>();
    public static void main(String[] args) throws FileNotFoundException {

        String totalText = "";

        Scanner scan = new Scanner(new File("files/samsa.txt"));
        while (scan.hasNextLine()) {
            totalText += scan.nextLine();
        }
        scan.close();

        for (int i=0; i<totalText.length()-SEED; i++) {
            String seed = totalText.substring(i, i+SEED);
            if (!seeds.containsKey(seed)) {
                seeds.put(seed, new ArrayList<>());
            }
            seeds.get(seed).add(totalText.substring(i+SEED, i+SEED+1));
            }
        String start = startingSeed();
        for (int i=0; i< 2000; i++) {
            String newChar = start.substring(start.length()-SEED);
            start += nextChar(newChar);
        }
        System.out.println(start);
        }

        public static String nextChar(String start) {
            int choices = seeds.get(start).size();
            int whichIndex = (int)(Math.random() * choices);
            return seeds.get(start).get(whichIndex);
        }

        public static String startingSeed() {
            int max = 0;
            String topKey = "";
            for (String key : seeds.keySet()) {
                if (seeds.get(key).size() > max) {
                    max = seeds.get(key).size();
                    topKey = key;
                }
            }
            return topKey;

        }


}
