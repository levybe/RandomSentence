import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ImprovedGenerator {

    private static final int SEED = 3;
    private static Map<ArrayList<String>, ArrayList<String>> seeds = new HashMap<>();
    private static ArrayList<String> allWords = new ArrayList<>(); // holds each word of the sample file

    public static void main(String[] args) throws IOException {

        File file = new File("files/hamlet.txt");
        Scanner scan = new Scanner(file);

        while (scan.hasNext()) {
            allWords.add(scan.next());
        }
        scan.close();

        createMap();
        generateText();


    }

    public static void createMap() {
        for (int i=0; i<allWords.size(); i++) {
            ArrayList<String> key = new ArrayList<>();
            for (int j=0; j<SEED-1; j++) { // if the SEED is 3, need to get 2 words as the key, the next one is a value
                key.add(allWords.get((i + j) % allWords.size()));
            }
            String nextWord = allWords.get((i+SEED-1) % allWords.size()); // Gets the value word
            if (seeds.containsKey(key)) {
                seeds.get(key).add(nextWord);
            } else {
                ArrayList<String> values = new ArrayList<>();
                values.add(nextWord);
                seeds.put(key, values);
            }
        }

    }

    public static ArrayList<String> getStartingKey() {
        ArrayList<String> start = new ArrayList<>();
        // Need to get a "random" key to start the text.
        int randomKey = (int)(Math.random() * seeds.size());
        int starting = 0;
        for (ArrayList<String> s: seeds.keySet()) {
            if (starting == randomKey) {
                start = s;
                break;
            }
            starting++;
        }
        return start;
    }

    public static void generateText() {
        String output = "";
        ArrayList<String> start = getStartingKey();

        for (int i=0; i<50; i++) { // output will be 200 words long
            ArrayList<String> value = seeds.get(start);
            String nextWord = value.get((int) (Math.random() * value.size())); // pick a random word from the values

            // "Shift" the current key to get the next one.
            start.remove(0);
            start.add(nextWord);
            output += nextWord + " ";
        }
        System.out.println(output);
    }

}

